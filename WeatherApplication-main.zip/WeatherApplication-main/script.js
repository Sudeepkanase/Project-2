const apiKey = 'fe8a12b1dd0697a52e8e89cd24229e83';

function getWeather() {
    const city = document.getElementById('city').value;
    if (!city) return alert('Please enter a city');

    const currentWeatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}`;

    fetch(currentWeatherUrl)
        .then(response => response.json())
        .then(data => displayWeather(data))
        .catch(() => alert('Error fetching current weather data. Please try again.'));

    fetch(forecastUrl)
        .then(response => response.json())
        .then(data => displayHourlyForecast(data.list))
        .catch(() => alert('Error fetching hourly forecast data. Please try again.'));
}

function displayWeather(data) {
    const { name, main, weather } = data;
    document.getElementById('temp-div').innerHTML = `<p>${Math.round(main.temp - 273.15)}°C</p>`;
    document.getElementById('weather-info').innerHTML = `<p>${name}</p><p>${weather[0].description}</p>`;
    const weatherIcon = document.getElementById('weather-icon');
    weatherIcon.src = `https://openweathermap.org/img/wn/${weather[0].icon}@4x.png`;
    weatherIcon.alt = weather[0].description;
    weatherIcon.style.display = 'block';
}

function displayHourlyForecast(hourlyData) {
    const hourlyForecastDiv = document.getElementById('hourly-forecast');
    hourlyForecastDiv.innerHTML = hourlyData.slice(0, 8).map(item => {
        const dateTime = new Date(item.dt * 1000);
        return `
            <div class="hourly-item">
                <span>${dateTime.getHours()}:00</span>
                <img src="https://openweathermap.org/img/wn/${item.weather[0].icon}.png" alt="Hourly Weather Icon">
                <span>${Math.round(item.main.temp - 273.15)}°C</span>
            </div>`;
    }).join('');
}
